import { Router, type IRouter } from "express";
import healthRouter from "./health";
import symptomsRouter from "./symptoms";

const router: IRouter = Router();

router.use(healthRouter);
router.use(symptomsRouter);

export default router;
